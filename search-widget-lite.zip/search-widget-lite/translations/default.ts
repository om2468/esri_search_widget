export default {
    _widgetLabel: 'Search Widget Lite',
    searchPlaceholder: 'Search for maps and layers...',
    searchButton: 'Search',
    searching: 'Searching...',
    noResults: 'No results found',
    resultsCount: '{count} results',
    errorMessage: 'Search failed. Please try again.'
};
